# Feature 16 — Testing and Release Readiness

## Objective

Ensure the platform is reliable enough for traders to use for research, backtesting, simulation and paper trading.

## Scope

### Included

- Backend unit tests
- Frontend component tests
- Integration tests
- Engine accuracy tests
- Demo data tests
- API contract tests
- Build verification
- Release checklist

### Excluded

- Real broker certification
- Exchange certification

## Backend Test Areas

| Area | Required Tests |
|---|---|
| Strategy schema | Save/load, invalid config, versioning |
| Strike selection | ATM, ITM, OTM, exact, premium, delta |
| Backtest engine | Entry, exit, SL, target, TSL |
| Adjustments | Re-entry, re-execute, move-to-cost, profit lock |
| Range breakout | Range calculation and trigger |
| Cost model | Brokerage, tax, slippage |
| Analytics | Drawdown, win rate, heatmaps |
| Simulator | Manual order, position, MTM |
| Forward test | Deployment lifecycle |
| Risk | Blockers, kill switch |
| Provider factory | Mock provider contract |

## Frontend Test Areas

| Area | Required Tests |
|---|---|
| Strategy builder | Add/edit/delete legs |
| Validation panel | Shows blockers and warnings |
| Option chain | Sort/filter/toggle Greeks |
| Charts | Indicators and markers |
| Backtest report | Metrics and export |
| Simulator | Play/pause/step/manual trade |
| Forward test | Deploy/stop/squareoff |
| Risk page | Kill switch |
| Portfolio | Add strategies and run backtest |

## Integration Test Flows

### Flow 1 — Strategy to Backtest

1. Create strategy.
2. Validate strategy.
3. Save strategy.
4. Run backtest.
5. View report.
6. Export report.

### Flow 2 — Strategy to Forward Test

1. Create saved strategy.
2. Deploy into Trade Simulator Forward Test mode.
3. Wait for virtual entry.
4. Verify virtual positions.
5. Trigger SL/target.
6. Square off.
7. Export forward test report.

### Flow 3 — Simulator Manual Trade

1. Open Trade Simulator.
2. Select NIFTY.
3. Add manual CE/PE legs.
4. Monitor MTM.
5. Exit one leg.
6. Square off all.
7. Export session.

### Flow 4 — Risk Kill Switch

1. Deploy two paper strategies.
2. Trigger kill switch.
3. Verify both deployments stopped.
4. Verify virtual positions closed.
5. Verify audit log.

## Build Commands

Backend:

```bash
pip install -r requirements.txt
python -m pytest
python -m uvicorn api.main:app --reload
```

Frontend:

```bash
cd frontend
npm install
npm run build
npm test
```

## Release Checklist

- Backend starts cleanly.
- Frontend builds cleanly.
- Demo mode works.
- Strategy save/load works.
- Backtest works.
- Trade Simulator works.
- Forward Test mode works.
- No real broker execution is enabled.
- All critical APIs have tests.
- API docs are available.
- Error messages are user-friendly.
- Audit logs are created for important actions.
- Exports work.
- README is updated.

## Definition of Done

A feature is complete only when:

- Backend API exists.
- UI exists.
- Validation exists.
- Tests exist.
- Audit logging exists where needed.
- Export exists where needed.
- Error handling exists.
- Demo data supports the feature.
- Documentation is updated.
