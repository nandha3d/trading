# Feature 14 — TradingView Webhook for Paper Mode

## Objective

Implement QuantMan-style TradingView alert support, but only for paper/simulator mode.

## Important Rule

TradingView webhook must never place real broker orders in this scope.

It can only:

- Start paper entry
- Trigger paper exit
- Update simulator signal state
- Record webhook event
- Trigger virtual strategy action

## Scope

### Included

- Webhook endpoint
- Secret validation
- Strategy mapping
- Signal event storage
- Paper-mode trigger
- Audit logging
- Webhook events UI

### Excluded

- Real broker execution
- Real order routing

## API

```http
POST /api/webhooks/tradingview
GET  /api/webhooks/tradingview/events
GET  /api/webhooks/tradingview/events/{event_id}
```

## Payload

```json
{
  "secret": "configured_secret",
  "strategy_id": "strategy_001",
  "deployment_id": "ft_001",
  "signal": "ENTRY",
  "symbol": "NIFTY",
  "direction": "BULLISH",
  "price": "{{close}}",
  "time": "{{time}}"
}
```

## Supported Signals

- ENTRY
- EXIT
- SQUARE_OFF
- PAUSE
- RESUME
- CUSTOM

## Validation

Reject when:

- Secret is invalid.
- Strategy does not exist.
- Deployment does not exist.
- Deployment is not paper mode.
- Market is closed for live signal.
- Signal is duplicate within configured debounce window.

## UI Components

```text
WebhookSettingsPage
TradingViewWebhookGuide
WebhookEventsTable
WebhookEventDetailsDrawer
```

## Acceptance Criteria

- Invalid secret returns 401/403.
- Valid webhook is stored.
- Webhook can trigger paper-mode signal.
- Event is visible in UI.
- No broker order is placed.
- Audit log clearly says PAPER MODE.

## Test Cases

1. Send webhook with invalid secret.
2. Send valid ENTRY signal.
3. Confirm event is stored.
4. Confirm paper deployment receives signal.
5. Send duplicate signal and confirm debounce.
6. Confirm no order API is called.
