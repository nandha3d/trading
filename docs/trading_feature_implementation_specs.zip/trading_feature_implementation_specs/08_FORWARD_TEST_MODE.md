# Feature 08 — Strategy Forward Test Mode inside Trade Simulator

## Objective

Implement AlgoTest-style forward testing as an automated mode inside the existing Trade Simulator.

## Important Definition

Forward Test means:

> A saved strategy runs on current/live market data and creates virtual orders/positions automatically. No real broker order is placed.

## Scope

### Included

- Deploy saved strategy into Trade Simulator
- Live/current data feed
- Virtual order lifecycle
- Virtual positions
- Running MTM
- Strategy status
- Auto entry
- Auto exit
- SL/target/TSL handling
- Re-entry/re-execute
- Stop/pause/resume
- Square-off
- Paper trade history
- Backtest vs forward test comparison
- Audit logs

### Excluded

- Real broker order placement
- Real broker square-off

## Deployment Lifecycle

```text
DRAFT → READY → WAITING_FOR_ENTRY → RUNNING → COMPLETED
                              ↓
                           STOPPED
                              ↓
                         SQUARE_OFF
```

## Backend APIs

```http
POST /api/simulator/forward-test/deploy
GET  /api/simulator/forward-test/deployments
GET  /api/simulator/forward-test/deployments/{deployment_id}
POST /api/simulator/forward-test/deployments/{deployment_id}/pause
POST /api/simulator/forward-test/deployments/{deployment_id}/resume
POST /api/simulator/forward-test/deployments/{deployment_id}/stop
POST /api/simulator/forward-test/deployments/{deployment_id}/squareoff
GET  /api/simulator/forward-test/deployments/{deployment_id}/positions
GET  /api/simulator/forward-test/deployments/{deployment_id}/orders
GET  /api/simulator/forward-test/deployments/{deployment_id}/trades
GET  /api/simulator/forward-test/deployments/{deployment_id}/mtm
GET  /api/simulator/forward-test/history
GET  /api/simulator/forward-test/deployments/{deployment_id}/audit
WS   /api/ws/simulator/forward-test/{deployment_id}
```

## Deployment Request

```json
{
  "strategy_id": "strategy_001",
  "symbol": "NIFTY",
  "trade_date": "2026-06-20",
  "virtual_capital": 500000,
  "mode": "PAPER",
  "risk_precheck_required": true,
  "auto_squareoff": true
}
```

## Virtual Order States

```text
CREATED → VALIDATED → FILLED
                 ↓
              REJECTED
```

## Virtual Position States

```text
OPEN → PARTIALLY_EXITED → CLOSED
```

## Entry Logic

1. Deployment is activated before entry time.
2. Strategy waits for entry conditions.
3. Strike is resolved using current option chain.
4. Risk precheck is run.
5. Virtual order is created.
6. Fill is simulated based on fill model.
7. Virtual position is opened.
8. Audit event is recorded.

## Exit Logic

Exit can happen due to:

- Leg SL
- Leg target
- Strategy SL
- Strategy target
- Trailing SL
- Profit lock
- Move-to-cost SL
- Exit time
- Manual square-off
- Kill switch
- Risk block

## Frontend Components

```text
ForwardTestModePanel
DeployStrategyModal
RunningDeploymentsPanel
ForwardTestStatusBadge
VirtualOrderBook
VirtualTradeBook
OpenPaperPositionsTable
RunningMtmCard
ForwardTestAuditTimeline
StopStrategyButton
PauseStrategyButton
ResumeStrategyButton
SquareOffButton
BacktestVsForwardComparison
```

## Backtest vs Forward Test Comparison

Compare:

- Expected entry time vs actual entry time
- Expected strike vs actual strike
- Expected premium vs actual fill price
- Backtest P&L vs paper P&L
- Slippage difference
- Exit reason difference
- MTM path difference

## Acceptance Criteria

- User can deploy saved strategy to Forward Test mode.
- Strategy waits until entry condition is met.
- Virtual orders are created.
- Running MTM updates in real time/current feed.
- User can stop, pause, resume and square off.
- Trade history is saved.
- No real broker order is placed.
- Every automated decision is available in audit timeline.

## Test Cases

1. Deploy short straddle strategy.
2. Confirm status becomes WAITING_FOR_ENTRY.
3. At entry time, confirm virtual orders are filled.
4. Confirm positions and MTM update.
5. Trigger SL and confirm exit.
6. Trigger re-entry if enabled.
7. Pause deployment.
8. Resume deployment.
9. Square off.
10. Compare with backtest result.
