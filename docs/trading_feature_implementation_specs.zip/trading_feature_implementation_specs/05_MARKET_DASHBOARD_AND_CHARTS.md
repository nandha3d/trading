# Feature 05 — Market Dashboard and Charts

## Objective

Build a StockMock/AlgoTest-style market dashboard and charting module for index options strategy research.

## Scope

### Included

- Market overview dashboard
- Index cards
- India VIX card
- Market regime
- Support/resistance
- Alerts
- Candle charts
- Option charts
- OI charts
- Straddle/strangle premium charts
- Multi-chart layout
- Strategy entry/exit markers

### Excluded

- Full TradingView charting library dependency unless separately decided
- Real order placement

## Dashboard Cards

Required cards:

- NIFTY spot
- BANKNIFTY spot
- FINNIFTY spot
- MIDCPNIFTY spot
- SENSEX spot
- BANKEX spot
- India VIX
- Market status
- PCR
- Max Pain
- Total CE OI
- Total PE OI
- Market regime

## Market Regime

Possible values:

- Strong bullish
- Mild bullish
- Sideways
- Mild bearish
- Strong bearish
- High volatility
- Low volatility
- Breakout
- Breakdown

## Chart Types

| Chart | Purpose |
|---|---|
| Index candle chart | Underlying movement |
| Option candle chart | CE/PE contract movement |
| Straddle premium chart | Combined ATM CE+PE premium |
| Strangle premium chart | Combined OTM CE+PE premium |
| OI chart | Strike-wise OI |
| OI change chart | Intraday OI change |
| Strategy MTM chart | P&L movement |
| Drawdown chart | Backtest drawdown |

## Indicators

- VWAP
- EMA 9
- EMA 21
- RSI
- ATR
- Supertrend
- Bollinger Bands
- CPR
- Previous day high/low
- Current day high/low
- Open range high/low
- Support/resistance
- Max Pain line
- Entry marker
- Exit marker
- SL line
- Target line
- TSL line

## Backend APIs

```http
GET /api/market/snapshot
GET /api/market/vix
GET /api/market/status
GET /api/market/levels
GET /api/market/regime
GET /api/market/alerts

GET /api/charts/candles
GET /api/charts/indicator
GET /api/charts/straddle
GET /api/charts/strangle
GET /api/charts/oi
GET /api/charts/strategy-mtm
GET /api/charts/backtest-markers

WS  /api/ws/market
```

## Frontend Components

```text
DashboardPage
MarketSummaryCards
MarketRegimeCard
SupportResistancePanel
MarketAlertsPanel
MultiChartPage
CandleChart
OptionChart
OIChart
StraddleChart
StrategyMtmChart
IndicatorSelector
ChartToolbar
```

## Multi-Chart Layout

User should be able to open up to 4 charts:

- NIFTY index
- BANKNIFTY index
- NIFTY ATM straddle
- Selected option contract

## Acceptance Criteria

- Dashboard shows current market status.
- India VIX is shown.
- User can open candle chart for index and option.
- User can apply VWAP/EMA overlays.
- User can view OI chart.
- User can view straddle/strangle premium.
- Backtest/simulator trades are shown as markers.
- Charts handle market closed state gracefully.

## Test Cases

1. Load dashboard.
2. Verify all index cards.
3. Open NIFTY chart.
4. Add VWAP and EMA.
5. Add previous day high/low.
6. Open option contract chart.
7. Open OI chart.
8. Show backtest markers.
9. Switch timeframe.
