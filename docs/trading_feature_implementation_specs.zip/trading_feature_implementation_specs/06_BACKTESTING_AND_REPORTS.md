# Feature 06 — Backtesting Engine and Reports

## Objective

Build a strong StockMock-style options backtesting engine and detailed analytics/reporting layer.

## Scope

### Included

- Multi-leg options backtesting
- Intraday and positional support
- Strategy templates backtesting
- Cost and slippage model
- Re-entry/re-execute simulation
- Move-to-cost simulation
- Profit lock simulation
- Detailed analytics
- Export to CSV, Excel and JSON
- Backtest comparison

### Excluded

- Real live broker execution

## Backend APIs

```http
POST /api/backtests
GET  /api/backtests
GET  /api/backtests/{run_id}
GET  /api/backtests/{run_id}/trades
GET  /api/backtests/{run_id}/analytics
GET  /api/backtests/{run_id}/export?format=csv
GET  /api/backtests/{run_id}/export?format=xlsx
GET  /api/backtests/{run_id}/export?format=json
POST /api/backtests/sweep
POST /api/backtests/compare
```

## Backtest Request

```json
{
  "strategy_id": "strategy_001",
  "from_date": "2024-01-01",
  "to_date": "2026-06-19",
  "initial_capital": 500000,
  "data_interval": "1m",
  "fill_model": "BID_ASK",
  "slippage_model": {
    "type": "PERCENT",
    "value": 0.5
  },
  "cost_model": {
    "brokerage": true,
    "stt": true,
    "exchange_charges": true,
    "gst": true,
    "stamp_duty": true,
    "sebi_charges": true
  }
}
```

## Engine Flow

1. Load strategy JSON.
2. Validate strategy.
3. Load market data.
4. Resolve expiry.
5. Resolve strikes at entry time.
6. Evaluate entry conditions.
7. Create virtual trades.
8. Monitor SL/target/TSL/profit lock.
9. Apply re-entry/re-execute.
10. Exit based on strategy rules.
11. Apply cost/slippage.
12. Store trades and summary.
13. Generate analytics.

## Metrics

- Net P&L
- Gross P&L
- Charges
- Slippage
- Win rate
- Loss rate
- Profit factor
- Expectancy
- Average profit
- Average loss
- Max profit
- Max loss
- Max drawdown
- Return on capital
- Sharpe-like ratio
- Consecutive wins
- Consecutive losses
- Best day
- Worst day

## Report Sections

- Summary
- Equity curve
- Drawdown curve
- Trade log
- Monthly P&L heatmap
- Year-wise P&L
- Daily P&L
- Weekday P&L
- DTE-wise performance
- Expiry-day performance
- Entry-time analysis
- Exit-reason analysis
- Leg-wise P&L
- Charges/slippage impact
- Monte Carlo simulation
- Overfitting risk
- Best/worst trades

## Frontend Components

```text
BacktestPage
BacktestRunForm
BacktestProgress
BacktestResultSummary
EquityCurve
DrawdownChart
TradeLogTable
MonthlyHeatmap
DTEAnalysisPanel
ExitReasonPanel
LegWisePerformance
MonteCarloPanel
OverfittingPanel
BacktestExportButton
BacktestComparePage
```

## Acceptance Criteria

- User can run backtest for date range.
- User can see progress.
- User can view all summary metrics.
- User can open full trade log.
- User can export CSV/Excel/JSON.
- User can compare two backtests.
- Missing data is reported clearly.
- Backtest does not silently skip important failures.

## Test Cases

1. Run short straddle backtest.
2. Run iron condor backtest.
3. Run strategy with re-entry.
4. Run strategy with profit lock.
5. Verify charges calculation.
6. Verify drawdown calculation.
7. Export Excel.
8. Compare two strategy runs.
9. Verify no data date shows warning.
