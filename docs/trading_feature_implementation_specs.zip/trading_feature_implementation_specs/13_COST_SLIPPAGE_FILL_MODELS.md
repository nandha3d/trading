# Feature 13 — Cost, Slippage and Fill Models

## Objective

Make backtest, simulator and forward test results realistic by supporting brokerage, taxes, slippage and different fill models.

## Scope

### Included

- Brokerage
- STT
- Exchange charges
- SEBI charges
- GST
- Stamp duty
- Slippage
- Bid/ask spread impact
- Fill model selection
- Cost breakdown report
- Slippage sensitivity

### Excluded

- Broker-specific real contract note reconciliation

## Cost Components

| Component | Applies To |
|---|---|
| Brokerage | Buy/Sell as configured |
| STT | Usually sell side for options |
| Exchange charges | Turnover |
| SEBI charges | Turnover |
| GST | Brokerage + transaction charges |
| Stamp duty | Buy side |
| Slippage | Entry/exit price impact |
| Spread cost | Bid/ask based fill |

## Fill Models

| Model | Behaviour |
|---|---|
| LTP | Fill at last traded price |
| CLOSE | Fill at candle close |
| NEXT_OPEN | Fill at next candle open |
| BID_ASK | Buy at ask, sell at bid |
| SLIPPAGE_POINTS | Add/subtract fixed points |
| SLIPPAGE_PERCENT | Add/subtract percent |
| LIQUIDITY_AWARE | Higher slippage for low OI/volume/wide spread |

## APIs

```http
GET  /api/settings/cost-model
PUT  /api/settings/cost-model
POST /api/costs/calculate
POST /api/costs/slippage-sensitivity
GET  /api/reports/backtest/{run_id}/cost-breakdown
```

## Example Config

```json
{
  "fill_model": "BID_ASK",
  "slippage": {
    "enabled": true,
    "type": "PERCENT",
    "value": 0.5
  },
  "charges": {
    "brokerage_per_order": 20,
    "stt_enabled": true,
    "exchange_charges_enabled": true,
    "sebi_charges_enabled": true,
    "gst_enabled": true,
    "stamp_duty_enabled": true
  }
}
```

## Acceptance Criteria

- User can configure fill model.
- Backtest shows gross and net P&L.
- Charges are visible per trade.
- Slippage sensitivity can be generated.
- Reports clearly mention cost assumptions.

## Test Cases

1. Run backtest with no charges.
2. Run same backtest with charges.
3. Compare gross vs net P&L.
4. Run bid/ask fill model.
5. Run slippage sensitivity.
