# Feature 11 — Portfolio Backtesting

## Objective

Implement AlgoTest-style portfolio testing where multiple strategies are combined and analysed together.

## Scope

### Included

- Create portfolio
- Add strategies
- Capital allocation
- Strategy weights
- Portfolio-level backtest
- Combined P&L
- Portfolio drawdown
- Strategy contribution
- Correlation matrix
- Portfolio heatmap
- Portfolio risk rules

### Excluded

- Real portfolio execution

## Portfolio Object

```json
{
  "portfolio_id": "portfolio_001",
  "name": "NIFTY Expiry Portfolio",
  "initial_capital": 1000000,
  "strategies": [
    {
      "strategy_id": "strategy_001",
      "allocation": 500000,
      "weight": 0.5,
      "enabled": true
    },
    {
      "strategy_id": "strategy_002",
      "allocation": 500000,
      "weight": 0.5,
      "enabled": true
    }
  ],
  "risk_settings": {
    "portfolio_max_loss": 30000,
    "daily_max_loss": 15000
  }
}
```

## APIs

```http
POST /api/portfolios
GET  /api/portfolios
GET  /api/portfolios/{portfolio_id}
PUT  /api/portfolios/{portfolio_id}
DELETE /api/portfolios/{portfolio_id}
POST /api/portfolios/{portfolio_id}/backtest
GET  /api/portfolios/{portfolio_id}/analytics
GET  /api/portfolios/{portfolio_id}/trades
GET  /api/portfolios/{portfolio_id}/correlation
GET  /api/portfolios/{portfolio_id}/export
```

## Analytics

- Portfolio net P&L
- Portfolio drawdown
- Portfolio equity curve
- Strategy-wise contribution
- Strategy-wise drawdown
- Correlation matrix
- Combined margin estimate
- Best/worst strategy
- Best/worst day
- Portfolio heatmap

## UI Components

```text
PortfolioPage
PortfolioBuilder
PortfolioStrategySelector
PortfolioAllocationPanel
PortfolioBacktestPanel
PortfolioAnalyticsPage
PortfolioCorrelationHeatmap
PortfolioContributionChart
PortfolioExportButton
```

## Acceptance Criteria

- User can create portfolio.
- User can add multiple saved strategies.
- User can allocate capital per strategy.
- User can run portfolio backtest.
- Portfolio P&L combines strategies correctly.
- Correlation matrix is shown.
- Portfolio report can be exported.

## Test Cases

1. Create portfolio with two strategies.
2. Run portfolio backtest.
3. Verify combined P&L.
4. Verify strategy contribution.
5. Verify correlation matrix.
6. Export portfolio report.
