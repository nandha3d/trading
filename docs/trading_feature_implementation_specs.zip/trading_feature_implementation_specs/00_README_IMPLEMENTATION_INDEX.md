# Trading Platform Feature Implementation Specs

This folder contains separate Markdown implementation files for each feature/module required to build StockMock-style, AlgoTest-style and QuantMan-style capabilities, excluding real live broker execution.

## Product Position

The product should become an India-focused options research, backtesting, simulation and paper-trading platform.

## Scope Included

- StockMock-style options backtesting
- Option chain with Greeks, OI and Max Pain
- Trade simulator
- Charts and OI charts
- AlgoTest-style no-code strategy builder
- Forward testing inside the existing Trade Simulator
- QuantMan-style adjustments such as re-entry, re-execute, move-to-cost and trailing SL
- Portfolio backtesting
- Risk controls and kill switch
- TradingView webhook support for paper mode only
- Data provider factory
- Reports and exports
- Testing and release readiness

## Scope Excluded

- Real broker order placement
- Real live algo execution
- Real exchange order routing
- Real position square-off through broker
- Broker-side order modify/cancel
- AI agent features

## Correct Product Mode Definition

| Mode | Meaning |
|---|---|
| Backtest | Runs strategy on historical data automatically |
| Historical Trade Simulator | Replays a past date and allows manual/virtual simulation |
| Live Manual Simulator | Uses live/current market data and lets the user manually create virtual positions |
| Strategy Forward Test | Runs a saved strategy automatically inside Trade Simulator using live/current feed and virtual orders |
| Live Broker Execution | Real broker orders. Not included in this scope. |

## Recommended Build Order

1. Platform stabilisation
2. Standard strategy JSON schema
3. Strategy builder completion
4. Backtesting and reports
5. Option chain completion
6. Market dashboard and charts
7. Trade simulator completion
8. Forward test mode inside Trade Simulator
9. Advanced adjustments
10. Risk management and kill switch
11. Portfolio backtesting
12. Data provider factory
13. TradingView webhook for paper mode
14. Testing and release readiness
