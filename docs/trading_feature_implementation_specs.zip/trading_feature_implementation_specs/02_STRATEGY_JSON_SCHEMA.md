# Feature 02 — Standard Strategy JSON Schema

## Objective

Create one standard strategy JSON format that works across:

- Strategy Builder
- Backtest
- Trade Simulator
- Forward Test Mode
- Portfolio Backtest
- Reports
- Risk Engine

## Why This Is Required

The existing strategy save/load flow has placeholder values in some areas. A standard schema prevents data loss between UI, backend and engines.

## Strategy Object

```json
{
  "id": "strategy_001",
  "name": "NIFTY Short Straddle with Re-entry",
  "description": "Intraday short straddle with SL and re-entry",
  "version": 1,
  "instrument": {
    "underlying": "NIFTY",
    "exchange": "NSE",
    "segment": "INDEX_OPTIONS",
    "trade_type": "INTRADAY",
    "expiry_selection": "CURRENT_WEEK"
  },
  "schedule": {
    "entry_start_time": "09:20",
    "entry_end_time": "09:25",
    "no_entry_after": "14:45",
    "exit_time": "15:15",
    "square_off_time": "15:20",
    "allowed_weekdays": ["MON", "TUE", "WED", "THU", "FRI"],
    "expiry_day_filter": "ALL"
  },
  "entry_conditions": [],
  "exit_conditions": [],
  "legs": [],
  "overall_risk": {},
  "adjustments": {},
  "cost_settings": {},
  "metadata": {
    "tags": ["short-straddle", "intraday"],
    "folder_id": null,
    "created_by": "system"
  }
}
```

## Leg Object

```json
{
  "leg_id": "leg_1",
  "name": "Sell ATM CE",
  "enabled": true,
  "transaction": "SELL",
  "option_type": "CE",
  "quantity": {
    "type": "LOTS",
    "lots": 1
  },
  "expiry": {
    "mode": "STRATEGY_DEFAULT"
  },
  "strike_selection": {
    "mode": "ATM",
    "offset_steps": 0,
    "exact_strike": null,
    "premium": null,
    "delta": null
  },
  "entry": {
    "type": "STRATEGY_ENTRY",
    "custom_conditions": []
  },
  "exit": {
    "type": "STRATEGY_EXIT",
    "custom_conditions": []
  },
  "stop_loss": {
    "enabled": true,
    "type": "PERCENT",
    "value": 30
  },
  "target": {
    "enabled": false,
    "type": "PERCENT",
    "value": null
  },
  "trailing_stop_loss": {
    "enabled": false,
    "type": "POINTS",
    "trail_by": 10,
    "lock_after_profit": 20
  },
  "re_entry": {
    "enabled": false,
    "trigger": "SL",
    "max_count": 0,
    "valid_until": "14:45",
    "mode": "SAME_STRIKE"
  },
  "re_execute": {
    "enabled": false,
    "trigger": "SL",
    "max_count": 0,
    "valid_until": "14:45",
    "selection_logic": "ORIGINAL_RULE"
  },
  "move_to_cost": {
    "enabled": false,
    "trigger": "OTHER_LEG_SL"
  }
}
```

## Condition Object

```json
{
  "condition_id": "cond_001",
  "left": {
    "source": "UNDERLYING",
    "field": "close",
    "indicator": null
  },
  "operator": "CROSSES_ABOVE",
  "right": {
    "source": "INDICATOR",
    "indicator": "VWAP",
    "value": null
  },
  "timeframe": "1m"
}
```

## Supported Strike Selection Modes

| Mode | Description |
|---|---|
| ATM | At-the-money strike |
| ITM_STEPS | ITM by strike steps |
| OTM_STEPS | OTM by strike steps |
| EXACT | Exact selected strike |
| PREMIUM_CLOSEST | Strike closest to premium |
| PREMIUM_GREATER_THAN | Premium greater than configured amount |
| PREMIUM_LESS_THAN | Premium less than configured amount |
| DELTA_CLOSEST | Delta closest to configured value |
| DELTA_GREATER_THAN | Delta greater than value |
| DELTA_LESS_THAN | Delta less than value |

## Backend Tasks

- Create Pydantic models for the full schema.
- Add schema validation.
- Add schema migration/version handling.
- Save full strategy JSON without transformation loss.
- Load full strategy JSON exactly as saved.

## Frontend Tasks

- Strategy Builder should maintain the same JSON shape.
- Remove placeholder fields such as hardcoded strike or expiry.
- Show human-readable strategy summary from JSON.

## Acceptance Criteria

- Strategy saved from UI reloads exactly.
- Strategy can be used in backtest without conversion errors.
- Same strategy can be deployed in simulator/forward test.
- Schema version is stored.
- Invalid strategy is blocked with clear error message.
