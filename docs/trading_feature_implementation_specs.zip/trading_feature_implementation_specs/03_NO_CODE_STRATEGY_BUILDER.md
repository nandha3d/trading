# Feature 03 — No-Code Strategy Builder

## Objective

Build an AlgoTest-style no-code strategy builder that allows users to create options strategies without coding.

## Scope

### Included

- Strategy details
- Instrument settings
- Entry/exit timing
- Entry condition builder
- Exit condition builder
- Up to 10 option legs
- Leg-wise SL/target/TSL
- Re-entry/re-execute settings
- Move-to-cost and profit lock settings
- Strategy templates
- Save, clone, edit, delete
- Strategy folders
- Validation panel

### Excluded

- Real broker deployment
- AI strategy generation

## UI Pages

```text
StrategyBuilderPage
StrategyLibraryPage
StrategyTemplateGallery
StrategyFolderPage
```

## Main Builder Sections

1. Strategy Name and Description
2. Instrument Settings
3. Entry/Exit Timing
4. Overall Entry Conditions
5. Overall Exit Conditions
6. Leg Builder
7. Leg-wise Settings
8. Adjustment Settings
9. Risk Settings
10. Cost Settings
11. Validation Summary
12. Save / Backtest / Simulate / Forward Test actions

## Instrument Settings

Fields:

- Underlying: NIFTY, BANKNIFTY, FINNIFTY, MIDCPNIFTY, SENSEX, BANKEX
- Segment: Options
- Trade type: Intraday / Positional
- Expiry: Current weekly, next weekly, current monthly, custom
- Quantity mode: Fixed lots, capital based, risk based
- Max legs: 10

## Entry and Exit Timing

Fields:

- Entry start time
- Entry end time
- No entry after
- Exit time
- Force square-off time
- Allowed weekdays
- Expiry day filter: All, expiry only, non-expiry only

## Leg Builder

Each leg must support:

- Buy/Sell
- CE/PE
- Expiry
- Strike selection
- Lots
- Entry condition override
- Exit condition override
- SL
- Target
- TSL
- Re-entry
- Re-execute
- Move to cost
- Profit lock participation

## Strategy Templates

Create templates for:

- Long Straddle
- Short Straddle
- Long Strangle
- Short Strangle
- Iron Condor
- Iron Butterfly
- Bull Call Spread
- Bear Put Spread
- Bull Put Spread
- Bear Call Spread
- Ratio Spread
- Calendar Spread
- Range Breakout Option Buying
- VWAP Trend Option Buying
- Expiry Short Straddle with Re-entry

## Backend APIs

```http
GET    /api/strategies
POST   /api/strategies
GET    /api/strategies/{strategy_id}
PUT    /api/strategies/{strategy_id}
DELETE /api/strategies/{strategy_id}
POST   /api/strategies/{strategy_id}/clone
POST   /api/strategies/{strategy_id}/validate
GET    /api/strategies/templates
POST   /api/strategies/from-template
GET    /api/strategy-folders
POST   /api/strategy-folders
PUT    /api/strategy-folders/{folder_id}
DELETE /api/strategy-folders/{folder_id}
```

## Validation Rules

Block save/run when:

- Strategy name is missing.
- No legs are added.
- More than 10 legs are added.
- Entry time is after exit time.
- No entry after time is after exit time.
- SL/target value is negative.
- Exact strike is not available for selected expiry.
- Premium/delta based strike cannot be resolved.
- Expiry data is unavailable.
- Naked short strategy exceeds configured risk limit.
- Quantity is zero.
- Conflicting conditions are configured.

## Acceptance Criteria

- User can create a strategy without coding.
- User can add/edit/delete up to 10 legs.
- User can save strategy and reload without data loss.
- User can clone a strategy.
- User can use a template.
- User can place strategies inside folders.
- Validation blocks invalid strategies.
- User can directly run Backtest, Simulator or Forward Test from builder.

## Test Cases

1. Create short straddle and save.
2. Reload saved strategy and verify JSON.
3. Clone strategy and edit expiry.
4. Add 10 legs and validate.
5. Try adding 11th leg and confirm block.
6. Use exact strike and validate strike.
7. Use premium-based strike and validate resolution.
8. Try invalid timing and confirm error.
