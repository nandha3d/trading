# Feature 15 — Reports, Exports and Audit Logs

## Objective

Create consistent reports, exports and audit logs across backtest, simulator, forward test and portfolio modules.

## Scope

### Included

- Backtest report export
- Simulator export
- Forward test export
- Portfolio export
- Trade logs
- Order logs
- Audit timeline
- Decision logs
- CSV, Excel and JSON export

### Excluded

- PDF export unless separately planned
- Broker contract note reconciliation

## Export Formats

| Format | Required |
|---|---|
| CSV | Yes |
| Excel XLSX | Yes |
| JSON | Yes |
| PDF | Optional later |

## Audit Events

| Event Type | Example |
|---|---|
| STRATEGY_CREATED | Strategy saved |
| STRATEGY_VALIDATED | Strategy passed/failed validation |
| BACKTEST_STARTED | Backtest run started |
| BACKTEST_COMPLETED | Backtest completed |
| SIMULATOR_MANUAL_ENTRY | User added virtual leg |
| SIMULATOR_MANUAL_EXIT | User exited virtual leg |
| FORWARD_DEPLOYED | Strategy deployed in paper mode |
| PAPER_ORDER_CREATED | Virtual order created |
| PAPER_ORDER_FILLED | Virtual order filled |
| PAPER_ORDER_REJECTED | Virtual order rejected by simulation/risk |
| SL_HIT | Stop loss hit |
| TARGET_HIT | Target hit |
| RE_ENTRY | Re-entry triggered |
| RE_EXECUTE | Re-execute triggered |
| MOVE_TO_COST | SL moved to cost |
| PROFIT_LOCK_TRIGGERED | Profit lock activated |
| KILL_SWITCH_TRIGGERED | Kill switch activated |
| RISK_BLOCKED | Risk engine blocked action |

## APIs

```http
GET /api/reports/backtest/{run_id}/export
GET /api/reports/simulator/{session_id}/export
GET /api/reports/forward-test/{deployment_id}/export
GET /api/reports/portfolio/{portfolio_id}/export

GET /api/audit
GET /api/audit/{event_id}
GET /api/audit/entity/{entity_type}/{entity_id}
```

## Export Content

### Backtest Export

- Summary
- Metrics
- Trades
- Charges
- Slippage
- Daily P&L
- Monthly P&L
- Exit reasons
- Leg-wise performance

### Simulator Export

- Session summary
- Manual orders
- Positions
- Trades
- MTM history
- Workspace settings

### Forward Test Export

- Deployment summary
- Virtual orders
- Virtual trades
- MTM history
- Audit timeline
- Backtest comparison

### Portfolio Export

- Portfolio summary
- Strategy contribution
- Combined trades
- Correlation matrix
- Portfolio equity curve

## Acceptance Criteria

- Each module has export option.
- Excel export has separate sheets.
- JSON export includes raw structured data.
- Audit logs are immutable.
- User can filter audit events by entity and date.

## Test Cases

1. Export backtest to Excel.
2. Export simulator session to CSV.
3. Export forward test to JSON.
4. Open audit timeline for paper deployment.
5. Filter audit events by strategy.
