# Feature 09 — Advanced Adjustments

## Objective

Implement QuantMan/AlgoTest-style strategy adjustments for backtest, simulator and forward test.

## Scope

### Included

- Re-entry
- Re-execute
- Move to cost
- Profit lock
- Trailing SL
- Manual adjustments
- Combined premium/basket view
- Adjustment audit logs

### Excluded

- Real broker position modification

---

# 1. Re-entry

## Definition

Re-entry waits for the original entry condition or price condition to occur again after a leg exits.

## Example

A sold CE leg exits due to SL. Re-entry waits for the configured condition and then enters again.

## Model

```json
{
  "re_entry": {
    "enabled": true,
    "trigger": "SL",
    "max_count": 2,
    "mode": "SAME_STRIKE",
    "valid_until": "14:45"
  }
}
```

## Acceptance Criteria

- Re-entry happens only after exit.
- Max count is respected.
- No re-entry after valid-until time.
- Trade log shows re-entry count.

---

# 2. Re-execute

## Definition

Re-execute immediately creates a fresh leg based on the original strike selection logic.

## Difference

| Feature | Behaviour |
|---|---|
| Re-entry | Waits for condition/price to return |
| Re-execute | Immediately selects fresh strike and enters |

## Model

```json
{
  "re_execute": {
    "enabled": true,
    "trigger": "SL",
    "max_count": 2,
    "selection_logic": "ORIGINAL_RULE",
    "valid_until": "14:45"
  }
}
```

## Acceptance Criteria

- Fresh strike is selected using original logic.
- Re-execute is immediate.
- Count is respected.
- Audit log shows old and new strike.

---

# 3. Move to Cost

## Definition

Move SL of remaining legs to their entry price after a trigger.

## Triggers

- One leg SL hit
- One leg target hit
- Strategy profit reaches amount
- Manual trigger
- Time trigger

## Model

```json
{
  "move_to_cost": {
    "enabled": true,
    "trigger": "LEG_SL_HIT",
    "apply_to": "REMAINING_LEGS",
    "buffer_points": 0
  }
}
```

## Acceptance Criteria

- SL is moved to entry price plus buffer.
- Event is visible in audit log.
- Works in backtest and forward test.

---

# 4. Profit Lock

## Definition

Lock a minimum profit after strategy MTM reaches a configured value.

## Model

```json
{
  "profit_lock": {
    "enabled": true,
    "trigger_profit": 5000,
    "lock_profit": 2500,
    "trail_profit": {
      "enabled": true,
      "step_profit": 1000,
      "increase_lock_by": 500
    }
  }
}
```

## Acceptance Criteria

- Profit lock triggers at configured MTM.
- Strategy exits if MTM falls below locked value.
- Trailing profit lock increases only in favourable direction.
- Report shows profit lock events.

---

# 5. Trailing SL

## Types

- Point based
- Percent based
- Step trailing
- Continuous trailing
- Premium based
- MTM based

## Acceptance Criteria

- SL trails only in favourable direction.
- TSL line appears on chart.
- TSL updates are logged.

---

# 6. Manual Adjustments

## Supported Actions

- Add leg
- Exit leg
- Modify SL
- Modify target
- Move SL to cost
- Pause automation
- Resume automation
- Square off
- Save current adjusted position as new strategy

## APIs

```http
POST /api/simulator/{session_id}/adjustments/add-leg
POST /api/simulator/{session_id}/adjustments/exit-leg
POST /api/simulator/{session_id}/adjustments/modify-sl
POST /api/simulator/{session_id}/adjustments/modify-target
POST /api/simulator/{session_id}/adjustments/move-to-cost
POST /api/simulator/{session_id}/adjustments/pause-automation
POST /api/simulator/{session_id}/adjustments/resume-automation
POST /api/simulator/{session_id}/adjustments/save-as-strategy
```

## Acceptance Criteria

- Manual adjustment affects only current simulator/forward-test state.
- Saved strategy is not modified unless user chooses Save as New Strategy.
- Every adjustment has audit event.
