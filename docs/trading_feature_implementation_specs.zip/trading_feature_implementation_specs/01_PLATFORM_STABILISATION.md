# Feature 01 — Platform Stabilisation

## Objective

Stabilise the existing backend and frontend before adding competitor-style features.

## Why This Is Required

The existing project already has many modules, but the earlier audit found route duplication, incomplete strategy save/load, a backend analytics import bug and incomplete test coverage. These must be fixed before adding large features.

## Scope

### Included

- Backend runtime cleanup
- Frontend build cleanup
- Route namespace cleanup
- Strategy JSON standardisation
- App configuration cleanup
- Demo data support
- Base test structure
- Error response standardisation

### Excluded

- New trading features
- Broker execution
- AI agent

## Backend Tasks

### 1. Fix Analytics Import Bug

In `api/routes/backtest.py`, update:

```python
from datetime import date, time
```

The analytics endpoint uses `date.fromisoformat(...)`, so `date` must be imported.

### 2. Remove Duplicate Strategy Routes

Current issue:

- Old route style: `/api/strategies/save`, `/api/strategies/list`
- New route style: `/api/strategies`, `/api/strategies/{strategy_id}`
- Duplicate delete route exists in more than one file.

Required final route structure:

```http
GET    /api/strategies
POST   /api/strategies
GET    /api/strategies/{strategy_id}
PUT    /api/strategies/{strategy_id}
DELETE /api/strategies/{strategy_id}
POST   /api/strategies/{strategy_id}/clone
POST   /api/strategies/{strategy_id}/validate
```

Payoff-specific routes should be moved under:

```http
POST /api/payoff/calculate
POST /api/payoff/builder
```

### 3. Standardise API Error Format

All APIs should return:

```json
{
  "success": false,
  "error_code": "INVALID_STRATEGY",
  "message": "Entry time must be before exit time.",
  "details": {}
}
```

### 4. Add `.env.example`

Required keys:

```env
APP_ENV=development
DATABASE_URL=sqlite:///./trading.db
DUCKDB_PATH=./data/options.duckdb
PARQUET_DATA_PATH=./data/parquet
DEFAULT_DATA_PROVIDER=demo
ENABLE_LIVE_BROKER_EXECUTION=false
WEBHOOK_SECRET=change-me
```

### 5. Add Demo Mode

Demo mode should allow the app to run without paid market data.

Required demo data:

- One NIFTY expiry
- One BANKNIFTY expiry
- At least 3 historical dates
- Sample option chain
- Sample backtest results
- Sample strategy templates

## Frontend Tasks

### 1. Clean Build

Commands to validate:

```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
npm run build
```

### 2. Central API Client

Create:

```text
frontend/src/lib/apiClient.ts
```

It should handle:

- Base URL
- Error response format
- Request timeout
- JSON parsing
- Auth placeholder for future use

### 3. Feature Flag System

Create:

```text
frontend/src/config/features.ts
```

Example:

```ts
export const FEATURES = {
  liveBrokerExecution: false,
  paperTrading: true,
  tradingViewWebhook: true,
  portfolioBacktesting: true
}
```

## Acceptance Criteria

- Backend starts without import errors.
- Frontend builds successfully.
- Strategy routes are not duplicated.
- App can run in demo mode.
- Every API failure returns standard error format.
- No real broker execution path is enabled.

## Test Cases

1. Start backend using `uvicorn`.
2. Open frontend in browser.
3. Create demo strategy.
4. Save and reload strategy.
5. Run demo backtest.
6. Confirm no duplicate route conflict.
7. Confirm broker execution flag is disabled.
