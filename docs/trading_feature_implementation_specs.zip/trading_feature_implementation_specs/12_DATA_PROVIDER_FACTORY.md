# Feature 12 — Data Provider Factory

## Objective

Create a common data-provider layer for historical data, live/current market data, option chain and broker metadata.

## Scope

### Included

- Provider interface
- Provider factory
- Demo provider
- DhanHQ adapter
- Upstox adapter
- Zerodha adapter
- Angel One adapter
- FYERS adapter
- Shoonya adapter
- TrueData adapter
- Global Datafeeds adapter
- Health check
- Fallback provider
- Provider settings UI

### Excluded

- Real order placement
- Broker order API

## Provider Interface

```python
class MarketDataProvider:
    def get_instruments(self): ...
    def get_expiries(self, symbol: str): ...
    def get_strikes(self, symbol: str, expiry: str): ...
    def get_spot_quote(self, symbol: str): ...
    def get_candles(self, instrument_key: str, interval: str, from_date: str, to_date: str): ...
    def get_option_chain(self, symbol: str, expiry: str): ...
    def get_option_quote(self, option_symbol: str): ...
    def subscribe_ticks(self, symbols: list[str]): ...
    def health_check(self): ...
```

## Provider Priority

1. Demo provider for local development
2. DhanHQ for option chain
3. Upstox for historical candles and expired data
4. Zerodha for historical/quote data if subscription exists
5. TrueData or Global Datafeeds for production-grade market feed
6. Angel One, FYERS, Shoonya as optional adapters

## Official Links

| Provider | Link |
|---|---|
| Upstox API Overview | https://upstox.com/developer/api-documentation/api-overview/ |
| Upstox Historical Candle V3 | https://upstox.com/developer/api-documentation/v3/get-historical-candle-data/ |
| Upstox Expired Historical Candles | https://upstox.com/developer/api-documentation/get-expired-historical-candle-data/ |
| DhanHQ API | https://dhanhq.co/docs/v2/ |
| DhanHQ Option Chain | https://dhanhq.co/docs/v2/option-chain/ |
| DhanHQ Expired Options | https://dhanhq.co/docs/v2/expired-options-data/ |
| Zerodha Kite Connect | https://kite.trade/docs/connect/v3/ |
| Zerodha Historical API | https://kite.trade/docs/connect/v3/historical/ |
| Zerodha Market Quotes | https://kite.trade/docs/connect/v3/market-quotes/ |
| Angel One SmartAPI | https://smartapi.angelbroking.com/ |
| FYERS API | https://myapi.fyers.in/ |
| Shoonya API | https://shoonya.com/api-documentation |
| Shoonya Python API | https://github.com/Shoonya-Dev/ShoonyaApi-py |
| TrueData | https://www.truedata.in/ |
| TrueData Python Client | https://pypi.org/project/truedata-ws/ |
| Global Datafeeds APIs | https://globaldatafeeds.in/apis/ |
| NSE Market Data Subscription | https://www.nseindia.com/static/market-data/real-time-data-subscription |

## Backend APIs

```http
GET /api/providers
GET /api/providers/{provider_name}/health
POST /api/providers/{provider_name}/test
GET /api/providers/active
PUT /api/providers/active
GET /api/providers/settings
PUT /api/providers/settings
```

## UI

Create:

```text
ProviderSettingsPage
ProviderHealthCard
ProviderCredentialForm
ProviderPrioritySelector
ProviderFallbackSettings
```

## Acceptance Criteria

- App can run with demo provider.
- Active provider can be changed from settings.
- Health check works.
- Option chain uses provider factory.
- Backtest data loader uses provider factory.
- API credentials are not hardcoded.
- No order-placement API is called.
