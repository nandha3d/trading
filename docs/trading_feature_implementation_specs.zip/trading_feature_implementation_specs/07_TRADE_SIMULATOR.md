# Feature 07 — Trade Simulator

## Objective

Complete the existing Trade Simulator as the central simulation workspace for:

- Historical replay
- Live/current manual virtual trading
- Strategy forward testing mode

## Current Base

The current screen already shows:

- Market closed/open status
- NIFTY/BANKNIFTY selector
- Expiry selector
- Date selector
- Time slider
- Spot price
- PCR
- Max Pain
- CE/PE OI
- OI intelligence
- Option chain
- Saved workspace
- Greeks toggle
- Export

## Scope

### Included

- Historical replay mode
- Live manual mode
- Workspace save/load
- Manual virtual order creation
- Virtual positions
- Running MTM
- Trade log
- Option chain integration
- Payoff view
- Greeks exposure
- Export
- Market closed handling

### Excluded

- Real broker execution

## Simulator Modes

| Mode | Description |
|---|---|
| Historical Replay | User selects past date and replays time |
| Live Manual | Uses current/live feed and lets user manually add virtual legs |
| Strategy Forward Test | Saved strategy runs automatically using live/current feed |

This file covers Historical Replay and Live Manual. Strategy Forward Test is covered separately.

## Backend APIs

```http
POST /api/simulator/sessions
GET  /api/simulator/sessions
GET  /api/simulator/sessions/{session_id}
POST /api/simulator/sessions/{session_id}/play
POST /api/simulator/sessions/{session_id}/pause
POST /api/simulator/sessions/{session_id}/step
POST /api/simulator/sessions/{session_id}/set-time
POST /api/simulator/sessions/{session_id}/set-speed
POST /api/simulator/sessions/{session_id}/manual-entry
POST /api/simulator/sessions/{session_id}/manual-exit
POST /api/simulator/sessions/{session_id}/squareoff
GET  /api/simulator/sessions/{session_id}/positions
GET  /api/simulator/sessions/{session_id}/orders
GET  /api/simulator/sessions/{session_id}/trades
GET  /api/simulator/sessions/{session_id}/mtm
POST /api/simulator/workspaces
GET  /api/simulator/workspaces
PUT  /api/simulator/workspaces/{workspace_id}
DELETE /api/simulator/workspaces/{workspace_id}
```

## Session Object

```json
{
  "session_id": "sim_001",
  "mode": "HISTORICAL_REPLAY",
  "symbol": "NIFTY",
  "expiry": "2026-06-23",
  "date": "2026-06-16",
  "current_time": "15:30",
  "status": "PAUSED",
  "market_status": "CLOSED",
  "positions": [],
  "orders": [],
  "trades": [],
  "mtm": 0
}
```

## Manual Entry Request

```json
{
  "leg_id": "manual_1",
  "transaction": "SELL",
  "option_type": "CE",
  "strike": 24000,
  "expiry": "2026-06-23",
  "lots": 1,
  "price_source": "LTP",
  "stop_loss": {
    "enabled": true,
    "type": "PERCENT",
    "value": 30
  }
}
```

## Frontend Components

```text
TradeSimulatorPage
SimulatorHeader
MarketStatusBadge
SimulatorDateTimeControls
SimulatorTimeSlider
SimulatorOptionChain
SimulatorWorkspacePanel
ManualOrderPanel
OpenPositionsTable
VirtualOrderBook
VirtualTradeBook
SimulatorMtmCard
PayoffPanel
GreeksExposurePanel
SimulatorExportButton
```

## Workspace

Workspace should store:

- Symbol
- Expiry
- Date
- Time
- Filters
- Selected strikes
- Manual legs
- View preferences
- Greeks toggle
- Chart layout

## Acceptance Criteria

- User can select date and time.
- User can move time slider.
- Market status is shown.
- User can manually add CE/PE legs.
- User can exit one leg.
- User can square off all positions.
- Running MTM updates.
- Workspace can be saved and reloaded.
- Export includes positions, orders, trades and summary.

## Test Cases

1. Open Trade Simulator.
2. Select NIFTY and expiry.
3. Select historical date.
4. Move time slider.
5. Add 24000 CE sell leg.
6. Add 23900 PE sell leg.
7. Verify MTM.
8. Exit one leg.
9. Square off all.
10. Save and reload workspace.
