# Feature 04 — Option Chain

## Objective

Implement a StockMock-style option chain with live/current market data, Greeks, OI analytics, PCR, Max Pain and strategy/simulator integration.

## Current Base

The Trade Simulator screenshot already shows:

- NIFTY/BANKNIFTY switch
- Expiry selector
- Date selector
- Market open/closed status
- PCR
- Max Pain
- CE/PE Open Interest
- OI intelligence
- Option chain
- Greeks toggle
- Saved workspace
- Export

This feature should complete and productionise that capability.

## Scope

### Included

- Real-time/current option chain
- Historical option chain for selected date/time
- Greeks
- OI and OI change
- Volume
- Bid/ask/spread
- PCR
- Max Pain
- Support/resistance from OI
- Add legs to strategy builder
- Add legs to trade simulator
- Export

### Excluded

- Real order placement

## Option Chain Fields

| Field | CE | PE | Required |
|---|---:|---:|---:|
| LTP | Yes | Yes | Yes |
| OI | Yes | Yes | Yes |
| OI Change | Yes | Yes | Yes |
| Volume | Yes | Yes | Yes |
| IV | Yes | Yes | Yes |
| Delta | Yes | Yes | Yes |
| Gamma | Yes | Yes | Yes |
| Theta | Yes | Yes | Yes |
| Vega | Yes | Yes | Yes |
| Bid | Yes | Yes | Yes |
| Ask | Yes | Yes | Yes |
| Spread | Yes | Yes | Yes |
| Liquidity Score | Yes | Yes | Yes |
| Intrinsic Value | Yes | Yes | Yes |
| Time Value | Yes | Yes | Yes |

## Filters

- Symbol
- Expiry
- Date
- Time
- ATM ± 5
- ATM ± 10
- All strikes
- Hide zero OI
- Min volume
- Min OI
- ITM/ATM/OTM
- Greeks toggle

## Analytics

### PCR

```text
PCR = Total PE OI / Total CE OI
```

### Max Pain

Calculate strike where option sellers have minimum payout.

### OI Intelligence

Output examples:

- Mild put dominance
- Call writing at resistance
- Put writing at support
- Short covering
- Long unwinding
- Spot near Max Pain
- Spot below support / above resistance

## Backend APIs

```http
GET /api/option-chain?symbol=NIFTY&expiry=2026-06-23&date=2026-06-16&time=15:30
GET /api/option-chain/expiries?symbol=NIFTY
GET /api/option-chain/strikes?symbol=NIFTY&expiry=2026-06-23
GET /api/option-chain/pcr?symbol=NIFTY&expiry=2026-06-23
GET /api/option-chain/max-pain?symbol=NIFTY&expiry=2026-06-23
GET /api/option-chain/oi-intelligence?symbol=NIFTY&expiry=2026-06-23
WS  /api/ws/option-chain?symbol=NIFTY&expiry=2026-06-23
```

## UI Components

```text
OptionChainPage
OptionChainTable
OptionChainFilters
OptionChainSummaryCards
OIIntelligencePanel
MaxPainCard
PCRCard
GreeksToggle
AddToStrategyButton
AddToSimulatorButton
OptionChainExportButton
```

## Integration

### Add to Strategy

When user clicks a CE/PE row:

```json
{
  "transaction": "SELL",
  "option_type": "CE",
  "strike_selection": {
    "mode": "EXACT",
    "exact_strike": 24000
  },
  "expiry": "2026-06-23"
}
```

### Add to Simulator

Creates a virtual/manual leg in the simulator workspace.

## Acceptance Criteria

- User can view option chain for selected symbol/expiry/date/time.
- User can switch between current/live and historical selected time.
- User can show/hide Greeks.
- PCR and Max Pain are calculated.
- OI intelligence is displayed.
- User can add CE/PE leg to strategy or simulator.
- Export includes visible fields.
- Market closed state is shown clearly.

## Test Cases

1. Load NIFTY option chain.
2. Change expiry.
3. Select ATM ± 10.
4. Hide zero OI.
5. Toggle Greeks.
6. Add 24000 CE to simulator.
7. Export option chain.
8. Verify PCR calculation.
9. Verify Max Pain calculation.
