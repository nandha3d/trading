# Feature 10 — Risk Management and Kill Switch

## Objective

Implement real risk controls for backtest, simulator and forward test modes.

## Scope

### Included

- Risk rules
- Risk precheck
- Order-level virtual risk check
- Strategy deployment risk check
- Daily max loss
- Strategy max loss
- Max trades
- Max open positions
- Max lots
- Spread/liquidity blocks
- Kill switch
- Audit logs
- Risk UI

### Excluded

- Real broker RMS
- Real order rejection handling from broker

## Risk Rules

| Rule | Action |
|---|---|
| Daily max loss exceeded | Block new trades and square off virtual positions |
| Strategy max loss exceeded | Stop strategy |
| Portfolio max loss exceeded | Stop all paper deployments |
| Max lots exceeded | Block entry |
| Max trades per day exceeded | Block new entries |
| Max re-entry exceeded | Block re-entry |
| Max re-execute exceeded | Block re-execute |
| Bid/ask spread too wide | Block or warn |
| OI too low | Block or warn |
| Volume too low | Block or warn |
| High VIX | Block or warn |
| No data | Block |
| Market closed | Block live forward entry |

## APIs

```http
POST /api/risk/precheck
POST /api/risk/evaluate-order
POST /api/risk/evaluate-position
POST /api/risk/evaluate-deployment
POST /api/risk/margin-estimate
POST /api/risk/slippage-sensitivity
POST /api/risk/kill-switch
POST /api/risk/kill-switch/reset
GET  /api/risk/rules
PUT  /api/risk/rules
GET  /api/risk/events
```

## Risk Response

```json
{
  "allowed": false,
  "severity": "BLOCKER",
  "block_reason": "Daily max loss limit exceeded",
  "warnings": [
    "Naked short exposure detected",
    "Bid/ask spread is above configured limit"
  ],
  "required_actions": [
    "Reduce lot size",
    "Add hedge leg"
  ]
}
```

## Kill Switch Behaviour

When triggered:

1. Stop all running forward-test deployments.
2. Stop all live manual simulator sessions.
3. Square off virtual positions.
4. Block new paper deployments.
5. Write audit event.
6. Show UI banner.
7. Allow reset only from Risk Control page.

## Risk UI

Create:

```text
RiskControlPage
RiskRulesPanel
RiskEventsTable
KillSwitchPanel
RiskPrecheckModal
MarginEstimateCard
SlippageSensitivityPanel
```

## Acceptance Criteria

- `allowed` is not always true.
- Risk blockers prevent strategy deployment.
- Kill switch stops actual running paper deployments, not hardcoded count.
- All risk decisions are logged.
- User can update risk rules.
- Risk UI clearly separates warning vs blocker.

## Test Cases

1. Deploy strategy within risk limit.
2. Deploy strategy exceeding max lots and confirm block.
3. Trigger daily loss and confirm strategy stops.
4. Trigger kill switch and confirm all paper deployments stop.
5. Reset kill switch.
6. Verify audit logs.
